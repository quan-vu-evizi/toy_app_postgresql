create function is_contained_2d(geometry, box2df) returns boolean
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT $2 OPERATOR(public.~) $1;
$$;
