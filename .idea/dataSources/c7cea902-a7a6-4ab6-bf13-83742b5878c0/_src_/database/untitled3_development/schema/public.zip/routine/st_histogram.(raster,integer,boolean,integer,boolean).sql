create function st_histogram(rast raster, nband integer, exclude_nodata_value boolean, bins integer, "right" boolean, OUT min double precision, OUT max double precision, OUT count bigint, OUT percent double precision) returns SETOF record
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT min, max, count, percent FROM public._ST_histogram($1, $2, $3, 1, $4, NULL, $5)
$$;
