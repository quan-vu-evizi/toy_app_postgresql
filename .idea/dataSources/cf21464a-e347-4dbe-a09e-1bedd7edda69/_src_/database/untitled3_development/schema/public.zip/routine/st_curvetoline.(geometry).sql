create function st_curvetoline(geometry) returns geometry
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT ST_CurveToLine($1, 32)
$$;
