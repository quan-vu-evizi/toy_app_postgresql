create function st_askml(text) returns text
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public._ST_AsKML(2, $1::public.geometry, 15, null);
$$;
