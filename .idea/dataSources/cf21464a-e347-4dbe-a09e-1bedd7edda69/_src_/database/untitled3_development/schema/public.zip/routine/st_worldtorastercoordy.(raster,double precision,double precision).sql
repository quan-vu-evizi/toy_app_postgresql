create function st_worldtorastercoordy(rast raster, xw double precision, yw double precision) returns integer
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT rowy FROM public._ST_worldtorastercoord($1, $2, $3)
$$;
